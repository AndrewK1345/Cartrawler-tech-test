import React from 'react';
import styled from 'styled-components';
import {BodyM} from "../styles/Typography.js";

const StyledModelContainer = styled.div`
    margin-top: 10px;
    padding: 10px;
    border-top: 1px solid #ddd;

    p {
        margin: 5px 0;
    }
`;

const ViewDetailsButton = styled.button`
    display: inline-block;
    margin-top: 10px;
    padding: 5px 10px;
    background-color: #e6356f;
    color: #ffffff;
    border: none;
    border-radius: 3px;
    cursor: pointer;

    &:hover {
        background-color: #333333;
    }
`;

const ModelContainer = ({ model, onViewDetails }) => (
    <StyledModelContainer>
            <BodyM>Model: {model.Name}</BodyM>
            <BodyM>Category: {model.Category}</BodyM>
            <BodyM>Price per day: €{model.CostPerDay.TotalCostPerDay}</BodyM>
            <BodyM>Fuel Type: {model.FuelType}</BodyM>
            <BodyM>Passenger Quantity: {model.PassengerQuantity}</BodyM>
            <ViewDetailsButton onClick={onViewDetails}>View Details</ViewDetailsButton>
    </StyledModelContainer>
);

export default ModelContainer;