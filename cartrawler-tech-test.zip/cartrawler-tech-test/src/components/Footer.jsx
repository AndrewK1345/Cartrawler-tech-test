import React from 'react';
import styled from 'styled-components';
import HertzLogo from '../assets/hertz.svg';
import AvisLogo from '../assets/avis.svg';
import AlamoLogo from '../assets/alamo.svg';
import PartnerLogo from '../assets/partner.svg';

const FooterContainer = styled.footer`
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    background-color: #333333;
    color: #ffffff;
    margin-top: 10px;

    img {
        height: auto;
        max-height: 40px;
        margin: 0 15px;
    }
`;

const Footer = () => (
    <FooterContainer>
        <img src={HertzLogo} alt="Hertz Logo" />
        <img src={AvisLogo} alt="Avis Logo" />
        <img src={AlamoLogo} alt="Alamo Logo" />
        <img src={PartnerLogo} alt="Partner Logo" />
    </FooterContainer>
);

export default Footer;