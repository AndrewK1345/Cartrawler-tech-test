import React from 'react';
import styled from 'styled-components';

const Input = styled.input`
    padding: 10px;
    border: 1px solid #e6356f;
    border-radius: 5px;
    width: 200px;
    margin-bottom: 10px;

    &:focus {
        border-color: #333333;
    }
`;

const SearchBar = ({ value, onChange, placeholder }) => (
    <Input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
    />
);

export default SearchBar;