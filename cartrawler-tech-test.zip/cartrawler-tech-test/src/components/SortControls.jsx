import React from 'react';
import styled from 'styled-components';
import { BodyS } from '../styles/Typography.js';

const SortControlsContainer = styled.div`
    display: flex;
    align-items: center;
    gap: 10px;
    margin-right: 100px;

    select, button {
        padding: 5px;
        border: 1px solid #333333;
        border-radius: 5px;
        background-color: #e6356f;
    }
`;

const SortControls = ({ sortOption, sortOrder, onSortOptionChange, onSortOrderToggle }) => {
    return (
        <SortControlsContainer>
            <BodyS htmlFor="sort">Sort by:</BodyS>
            <select id="sort" value={sortOption} onChange={(e) => onSortOptionChange(e.target.value)}>
                <option value="Price">Price</option>
                <option value="Vendor">Vendor</option>
            </select>
            <button onClick={onSortOrderToggle}>
                {sortOrder === 'asc' ? 'Ascending' : 'Descending'}
            </button>
        </SortControlsContainer>
    );
};

export default SortControls;