import React, { useState } from 'react';
import styled from 'styled-components';
import { FaStar } from 'react-icons/fa';
import ModelContainer from './ModelContainer.jsx';
import CarDetailsModal from '../pages/CarDetailsModal.jsx';
import { TitleM } from '../styles/Typography.js';

const CarCardContainer = styled.div`
    background-color: #ffffff;
    border: 1px solid #ddd;
    border-radius: 5px;
    padding: 15px;
    width: 300px;
`;

const HeaderContainer = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
`;

const FavouriteButton = styled.button`
    background: none;
    border: none;
    cursor: pointer;
    color: ${(props) => (props.isFavorite ? '#e6356f' : '#ddd')};
    font-size: 24px;

    &:hover {
        color: ${(props) => (props.isFavorite ? '#c02d5c' : '#bbb')};
    }
`;

const CarCard = ({ car, isFavorite, onFavoriteToggle }) => {
    const [selectedModel, setSelectedModel] = useState(null);

    const handleViewDetails = (model) => {
        setSelectedModel(model);
    };

    const closeModal = () => {
        setSelectedModel(null);
    };

    return (
        <>
            <CarCardContainer>
                <HeaderContainer>
                    <TitleM>{car.Vendor}</TitleM>
                    <FavouriteButton isFavorite={isFavorite} onClick={onFavoriteToggle}>
                        <FaStar />
                    </FavouriteButton>
                </HeaderContainer>
                {car.Models.map((model, index) => (
                    <ModelContainer key={index} model={model} onViewDetails={() => handleViewDetails(model)} />
                ))}
            </CarCardContainer>
            {selectedModel && (
                <CarDetailsModal car={car} model={selectedModel} onClose={closeModal} />
            )}
        </>
    );
};

export default CarCard;