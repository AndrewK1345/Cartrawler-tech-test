import React from 'react';
import styled from 'styled-components';
import { BodyS } from '../styles/Typography.js';

const LegendContainer = styled.div`
    background-color: #ffffff;
    border: 1px solid #e6356f;
    border-radius: 5px;
    padding: 5px;
    margin-bottom: 20px;
    width: 200px;
`;

const Legend = ({ pickupInfo, returnInfo }) => {
    return (
        <LegendContainer>
            <BodyS><strong>Pickup:</strong> {pickupInfo.Location} at {pickupInfo.Time}</BodyS>
            <BodyS><strong>Return:</strong> {returnInfo.Location} at {returnInfo.Time}</BodyS>
        </LegendContainer>
    );
};

export default Legend;