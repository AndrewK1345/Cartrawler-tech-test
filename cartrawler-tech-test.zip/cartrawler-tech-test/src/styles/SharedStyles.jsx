import styled from 'styled-components';

export const Container = styled.div`
    padding-left: 20px;
    background-color: #ffffff;
    color: #333333;
    min-height: 100vh;
    min-width: 100vw;
    flex-direction: column;
    display: flex;
`;

export const Overlay = styled.div`
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(61, 54, 54, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
`;

export const Modal = styled.div`
    background: #ffffff;
    border-radius: 10px;
    padding: 20px;
    max-width: 500px;
    width: 90%;
    text-align: center;
`;

export const Button = styled.button`
    background: #e6356f;
    color: #ffffff;
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    cursor: pointer;

    &:hover {
        background: #333333;
    }
`;

export const InfoContainer = styled.div`
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    margin: 10px;

    img {
        width: 24px;
        height: 24px;
    }
`;