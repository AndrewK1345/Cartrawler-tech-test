import styled from 'styled-components';

export const TitleXL = styled.h1`
    font-family: 'Open Sans', sans-serif;
    font-size: 3rem;
    line-height: 4.063rem;
    font-weight: bold;
`;

export const TitleL = styled.h2`
    font-family: 'Open Sans', sans-serif;
    font-size: 2.625rem;
    line-height: 3.563rem;
    font-weight: bold;
`;

export const TitleM = styled.h3`
    font-family: 'Open Sans', sans-serif;
    font-size: 2.25rem;
    line-height: 3.063rem;
    font-weight: bold;
`;

export const TitleS = styled.h4`
    font-family: 'Open Sans', sans-serif;
    font-size: 2rem;
    line-height: 2.688rem;
    font-weight: bold;
`;

export const SubtitleXL = styled.h5`
    font-family: 'Open Sans', sans-serif;
    font-size: 1.75rem;
    line-height: 2.375rem;
    font-weight: semibold;
`;

export const SubtitleL = styled.h6`
    font-family: 'Open Sans', sans-serif;
    font-size: 1.5rem;
    line-height: 2.063rem;
    font-weight: semibold;
`;

export const SubtitleM = styled.p`
    font-family: 'Open Sans', sans-serif;
    font-size: 1.25rem;
    line-height: 1.688rem;
    font-weight: semibold;
`;

export const SubtitleS = styled.p`
    font-family: 'Open Sans', sans-serif;
    font-size: 1.125rem;
    line-height: 1.5rem;
    font-weight: semibold;
`;

export const BodyL = styled.p`
    font-family: 'Open Sans', sans-serif;
    font-size: 1rem;
    line-height: 1.375rem;
    font-weight: regular;
`;

export const BodyM = styled.p`
    font-family: 'Open Sans', sans-serif;
    font-size: 0.875rem;
    line-height: 1.188rem;
    font-weight: regular;
`;

export const BodyS = styled.p`
    font-family: 'Open Sans', sans-serif;
    font-size: 0.75rem;
    line-height: 1.063rem;
    font-weight: regular;
`;