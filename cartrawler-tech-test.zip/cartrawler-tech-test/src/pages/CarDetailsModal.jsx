import React from 'react';
import { Overlay, Modal, Button, InfoContainer } from '../styles/SharedStyles.jsx';
import FuelIcon from '../assets/fuel.svg';
import PersonIcon from '../assets/person.svg';
import { TitleL, BodyM, TitleM } from '../styles/Typography.js';

const CarDetailsModal = ({ car, model, onClose }) => (
    <Overlay>
        <Modal>
            <TitleL>{car.Vendor}</TitleL>
            <TitleM>{model.Name}</TitleM>
            <BodyM>Category: {model.Category}</BodyM>
            <BodyM>Price per day: €{model.CostPerDay.TotalCostPerDay}</BodyM>
            <InfoContainer>
                <img src={FuelIcon} alt="Fuel Icon" />
                <BodyM>Fuel Type: {model.FuelType}</BodyM>
            </InfoContainer>
            <InfoContainer>
                <img src={PersonIcon} alt="Passenger Icon" />
                <BodyM>Passenger Quantity: {model.PassengerQuantity}</BodyM>
            </InfoContainer>
            <Button onClick={onClose}>Close</Button>
        </Modal>
    </Overlay>
);

export default CarDetailsModal;