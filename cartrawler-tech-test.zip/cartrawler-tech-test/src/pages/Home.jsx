import React, { useEffect, useState, useMemo } from 'react';
import styled from 'styled-components';
import { Container } from '../styles/SharedStyles.jsx';
import CarCard from '../components/CarCard.jsx';
import { BodyS } from '../styles/Typography.js';
import Footer from "../components/Footer.jsx";
import CarTrawlerLogo from '../assets/cartrawler-logo.png';
import SearchBar from "../components/SearchBar.jsx";
import SortControls from '../components/SortControls.jsx';
import Legend from '../components/Legend.jsx';

const Header = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 20px;
`;

const CarList = styled.div`
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
`;

const ToggleButton = styled.button`
    background: ${(props) => (props.active ? '#e6356f' : '#ddd')};
    color: #fff;
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    cursor: pointer;
    margin: 10px;

    &:hover {
        background: ${(props) => (props.active ? '#c02d5c' : '#ddd')};
    }
`;

const Home = () => {
    const [cars, setCars] = useState([]);
    const [pickupInfo, setPickupInfo] = useState(null);
    const [returnInfo, setReturnInfo] = useState(null);
    const [sortOption, setSortOption] = useState('Price');
    const [sortOrder, setSortOrder] = useState('asc');
    const [searchQuery, setSearchQuery] = useState('');
    const [favorites, setFavorites] = useState([]);
    const [showFavorites, setShowFavorites] = useState(false);

    useEffect(() => {
        fetch('/cars.json')
            .then((response) => response.json())
            .then((data) => {
                setCars(data.Vehicles);
                setPickupInfo(data.Pickup);
                setReturnInfo(data.Return);
            });
    }, []);

    const toggleFavorite = (carId) => {
        setFavorites((prevFavorites) =>
            prevFavorites.includes(carId)
                ? prevFavorites.filter((id) => id !== carId)
                : [...prevFavorites, carId]
        );
    };

    const filteredCars = useMemo(() => {
        return cars.filter((car) =>
            car.Vendor.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }, [cars, searchQuery]);

    const sortedCars = useMemo(() => {
        return [...filteredCars].sort((a, b) => {
            const valueA = sortOption === 'Price' ? a.Models[0].CostPerDay.TotalCostPerDay : a.Vendor;
            const valueB = sortOption === 'Price' ? b.Models[0].CostPerDay.TotalCostPerDay : b.Vendor;

            if (valueA < valueB) return sortOrder === 'asc' ? -1 : 1;
            if (valueA > valueB) return sortOrder === 'asc' ? 1 : -1;
            return 0;
        });
    }, [filteredCars, sortOption, sortOrder]);

    const displayedCars = useMemo(() => {
        return showFavorites
            ? sortedCars.filter((car) => favorites.includes(car.Id))
            : sortedCars;
    }, [sortedCars, favorites, showFavorites]);

    return (
        <Container>
            <Header>
                <img src={CarTrawlerLogo} alt="CarTrawler Logo" />
                <SortControls
                    sortOption={sortOption}
                    sortOrder={sortOrder}
                    onSortOptionChange={setSortOption}
                    onSortOrderToggle={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                />
            </Header>
            {pickupInfo && returnInfo && (
                <Legend pickupInfo={pickupInfo} returnInfo={returnInfo} />
            )}
            <SearchBar
                value={searchQuery}
                onChange={setSearchQuery}
                placeholder="Search cars..."
            />
            <div>
                <ToggleButton
                    active={!showFavorites}
                    onClick={() => setShowFavorites(false)}
                >
                    All Cars
                </ToggleButton>
                <ToggleButton
                    active={showFavorites}
                    onClick={() => setShowFavorites(true)}
                >
                    Favorites
                </ToggleButton>
            </div>
            <CarList>
                {displayedCars.length > 0 ? (
                    displayedCars.map((car) => (
                        <CarCard
                            key={car.Id}
                            car={car}
                            isFavorite={favorites.includes(car.Id)}
                            onFavoriteToggle={() => toggleFavorite(car.Id)}
                        />
                    ))
                ) : (
                    <BodyS>No cars match your criteria.</BodyS>
                )}
            </CarList>
            <Footer />
        </Container>
    );
};

export default Home;